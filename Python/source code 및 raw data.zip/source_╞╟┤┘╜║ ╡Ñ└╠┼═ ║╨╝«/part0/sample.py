# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

a = 5
print(a)

a = a + 5
print(a) 
