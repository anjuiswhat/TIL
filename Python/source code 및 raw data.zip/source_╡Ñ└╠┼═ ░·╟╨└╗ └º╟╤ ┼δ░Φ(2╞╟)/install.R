install.packages('vioplot')
install.packages('corrplot')
install.packages('gmodels')
install.packages('matrixStats')

install.packages('lmPerm')
install.packages('pwr')

install.packages('FNN')
install.packages('DMwR')

install.packages('xgboost')

install.packages('ellipse')
install.packages('mclust')
install.packages('ca')
install.packages('ggrepel')

install.packages('klaR')
install.packages('hexbin')
